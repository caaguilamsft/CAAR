<#
.SYNOPSIS
 
.NOTES
    Author: MDATP OPS Team
    Date/Version: See $ScriptVer
#>
param (
    [string]$outputDir = $PSScriptRoot, 
    ##Enter Url or IpAddress for Proxy
    [Alias("p")][string]$manualProxy = "", 
    ## To collect netsh traces -n 
    [Alias("n")][switch]$netTrace,
    [Alias("w", "wfp")][switch]$wfpTrace,
    ##To collect Sense performance traces '-l' or '-h'
    [Alias("l")][switch]$wprpTraceL,
    [Alias("h")][switch]$wprpTraceH,
	##To collect Sense app compat traces '-c'
    [Alias("c")][switch]$AppCompatC,
	##To collect Sense dumps '-d'
	[Alias("d")][switch]$CrashDumpD,
	##To collect traces for isolation issues '-i'
	[Alias("i")][switch]$NetTraceI,
	##To collect boot traces issues at startup '-b'
	[Alias("b")][switch]$BootTraceB,
	##To collect traces for WD AntiVirus pref issues '-a'
	[Alias("a")][switch]$WDPerfTraceA,
	##To collect verbose traces for WD AntiVirus issues '-v'
	[Alias("v")][switch]$WDVerboseTraceV,
	##To prepare the machine for full dump collection '-z'
	[Alias("z")][switch]$FullCrashDumpZ,
	##To set the machine for remote data collection '-r'
	[Alias("r")][switch]$RemoteRun,
	##To set the minutes to run for data collection '-m'
	[Alias("m")][int]$MinutesToRun = "5",
	##To crash the machine and create a memory dump immediately '-k'
	[Alias("K")][switch]$notmyfault
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8  # MDATPClientAnalyzer.exe outputs UTF-8, so interpret its output as such

# Define outputs
$resultOutputDir = Join-Path $outputDir "MDATPClientAnalyzerResult"
$psrFile = Join-Path $resultOutputDir "Psr.zip"
$ProcMonlog = Join-Path $resultOutputDir "Procmonlog.pml"
$connectivityCheckFile = Join-Path $resultOutputDir "MDATPClientAnalyzer.txt"
$connectivityCheckUserFile = Join-Path $resultOutputDir "MDATPClientAnalyzer_User.txt"
$MsSenseDump = Join-Path $resultOutputDir "MsSense.dmp"
$MsSenseSDump = Join-Path $resultOutputDir "MsSenseS.dmp"
$outputZipFile = Join-Path $outputDir "MDATPClientAnalyzerResult.zip"
$WprpTraceFile = Join-Path  $resultOutputDir "FullSenseClient.etl"
$OSPreviousVersion = $false
$AVPassiveMode = $false
$EndpointList = Join-Path $outputDir "endpoints.txt"
$ScriptVer = "09032020"

# function to read Registry Value
function Get-RegistryValue { param (
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$Path,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$Value
    )

    if (Test-Path -path $Path) {
        return Get-ItemProperty -Path $Path | Select-Object -ExpandProperty $Value -ErrorAction silentlycontinue
    } else {
        return $false
    }
}

function Set-BootTraces {
	$ProcmonCommand = Join-Path $outputDir "Procmon.exe"
	Write-Host "Checking if WPR Boot trace is already running"
	$WptState = Check-WptState
	if ((!$OSPreviousVersion) -and ($WptState -eq "Ready")) {
		Start-Process -wait -WindowStyle minimized wpr.exe -ArgumentList "-boottrace -stopboot `"$WprpTraceFile`"" | out-Null
	}
	Write-Host "Saving any running ProcMon Boot trace"
	Start-Process -wait $ProcmonCommand -ArgumentList "-accepteula -convertbootlog `"$ProcMonlog`""
	$procmonlogs = Get-Item "$resultOutputDir\*.pml"
	if ($procmonlogs -eq $null) {
		& $ProcmonCommand -accepteula -enablebootlogging -nofilter -quiet -minimized
		if ((!$OSPreviousVersion) -and ($WptState -eq "Ready")) {
			&wpr.exe -boottrace -addboot "$outputDir\Sense.wprp" -filemode 
		}
		Write-Host "Boot logging ready"
		Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please run the tool again with '-b' parameter when the machine is back online" 
		if ($RemoteRun) {
			Write-Warning "Restarting remote machine..."
		} else {
			Read-Host "Press ENTER when you are ready to restart..."
		}
		Restart-Computer -ComputerName . -Force
	}
	else {
		Write-Host "Boot logs were collected successfully"
		Get-DefenderAV
	}
}

function Set-FullCrashDump {
	Set-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -name CrashDumpEnabled -Type DWord -Value "1"
	Write-Host "Registry settings for full dump collection have been configured"
}

function Set-CrashOnCtrlScroll {
	Set-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Services\i8042prt\Parameters' -name CrashOnCtrlScroll -Type DWord -Value "1"
	Set-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Services\kbdhid\Parameters' -name CrashOnCtrlScroll -Type DWord -Value "1"
	Set-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Services\hyperkbd\Parameters' -name CrashOnCtrlScroll -Type DWord -Value "1" -ErrorAction SilentlyContinue
	Write-Host "Registry settings for CrashOnCtrlScroll have been configured as per https://docs.microsoft.com/en-us/windows-hardware/drivers/debugger/forcing-a-system-crash-from-the-keyboard"
}

function Start-PSRRecording {
	if ($RemoteRun) {
		"`r`nSkipping PSR recording as it requires an interactive user session." | Out-File $connectivityCheckFile -Append
	} 
	else {
		& psr.exe -stop
		Start-Sleep -Seconds 2
		& psr.exe -start -output "$resultOutputDir\psr.zip" -gui 0 -maxsc 99 -sc 1
	}
}

function Stop-PSRRecording {
	if ($RemoteRun) {
		"`r`nSkipping PSR recording as it requires an interactive user session." | Out-File $connectivityCheckFile -Append
	} 
	else {
		& psr.exe -stop
	}
}

function Stop-MpCmdRunTrace {
	$MpCmdRunProcess = Get-Process | Where-Object {$_.MainWindowTitle -like "*MpCmdRun.ex*"}
	start-sleep 1
	if ($MpCmdRunProcess) {
		[void][WindowFocus]::SetForeGroundWindow($MpCmdRunProcess.MainWindowHandle) 
		[System.Windows.Forms.SendKeys]::SendWait("~")
	}
}

function Get-WdAvVerboseTrace {
	if (!$OSPreviousVersion) {
		Start-Process -WindowStyle minimized MpCmdRun.exe -WorkingDirectory $CurrentMpCmdPath -ArgumentList "-trace -grouping ff -level ff"
		&$MpCmdRunCommand -CaptureNetworkTrace -path C:\Users\Public\Downloads\Capture.npcap
		Start-WinEventDebug Microsoft-Windows-SmartScreen/Debug
	}
	elseif (Test-Path -path "$env:ProgramFiles\Microsoft Security Client\MpCmdRun.exe") {
		Start-Process -WindowStyle minimized MpCmdRun.exe -WorkingDirectory $CurrentMpCmdPath -ArgumentList "-trace -grouping ff -level ff"
	}
	start-Sleep 1
	Start-PSRRecording
	$MinutesToRun = Get-MinutesValue
	StartTimer
	Stop-PSRRecording
	Get-DefenderAV
	if (Test-Path -Path  $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-SmartScreen%4Debug.evtx') {
		Stop-WinEventDebug Microsoft-Windows-SmartScreen/Debug
		Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-SmartScreen%4Debug.evtx' -Destination $resultOutputDir\EventLogs\SmartScreen.evtx
	}
}

function Get-WdAvPerfTrace {
	$WptState = (check-WptState xperf.exe)
	if ($WptState -eq "Ready") {
		Write-Host "Starting XPERF trace"
		Start-Process -WindowStyle minimized XPERF.exe -WorkingDirectory $resultOutputDir -ArgumentList "-on Base+DiagEasy+Latency+FileIO+DISPATCHER+REGISTRY+PERF_COUNTER -stackWalk Profile+CSwitch+ReadyThread+FileCreate+FileClose -f Kernel.etl -BufferSize 1024"
		start-Sleep 1
		Start-Process -WindowStyle minimized XPERF.exe -WorkingDirectory $resultOutputDir -ArgumentList "-start AMXperf -on e4b70372-261f-4c54-8fa6-a5a7914d73da+cfeb0608-330e-4410-b00d-56d8da9986e6+8e92deef-5e17-413b-b927-59b2f06a3cfc+751ef305-6c6e-4fed-b847-02ef79d26aef+0A002690-3839-4E3A-B3B6-96D8DF868D99 -f amxperftrace.etl"
		start-Sleep 1
		$MinutesToRun = Get-MinutesValue
		StartTimer
		Start-Process -WindowStyle minimized XPERF.exe -WorkingDirectory $resultOutputDir -ArgumentList "-stop -stop AMXperf"
		Write-Host "Stopping XPERF trace"
		start-Sleep 5
		Write-Host "Merging XPERF trace"
		Start-Process -WindowStyle minimized XPERF.exe -WorkingDirectory $resultOutputDir -ArgumentList "-merge Kernel.etl amxperftrace.etl Merged.etl -compress"
	}
	Get-DefenderAV
}

function Get-CrashDumps {
	$buildNumber = ([System.Environment]::OSVersion).Version.build
	New-Item -ItemType Directory -Path "$resultOutputDir\CrashDumps" -ErrorAction SilentlyContinue | out-Null
	Write-Host "Attempting to collect a memory dump of the sensor"
	$ProcDumpCommand = Join-Path $outputDir "procdump.exe" 
    if ($OSPreviousVersion) {
		$processes = @(Get-Process -Name MsSenseS) + @(Get-Process -Name MonitoringHost)
        if ($processes -eq $null) {
			Write-Host "No running Sensor processes found"
		}
		else {
			foreach ($process in $processes) {
				& $ProcDumpCommand -accepteula -ma -mk $process.Id "$resultOutputDir\CrashDumps\$($process.name)_$($process.Id).dmp"
			}
		}
    }
    elseif ($buildNumber -ge "15063") {
		Write-Host "The MDATPClientAnalyzer does not support capturing a memory dump of a tamper protected process at this time."
		Write-Host "Attempting to capture a memory dump of the DiagTrack service"
		$DiagTrackID = (TASKLIST /SVC /FI �"SERVICES eq diagtrack" /FO CSV | ConvertFrom-Csv).PID
		if ($DiagTrackID -eq $null) {
			Write-Host "The DiagTrack service is not running"
		}
		else {
			& $ProcDumpCommand -accepteula -ma -mk $DiagTrackID "$resultOutputDir\CrashDumps\DiagTrack.dmp"
		}
	}
}

function Get-NetTraces {
	New-Item -ItemType Directory -Path "$resultOutputDir\NetTraces" -ErrorAction SilentlyContinue | out-Null
	$traceFile = "$resultOutputDir\NetTraces\NetTrace.etl"
    $WptState = Check-WptState
	Start-Wpr
    &netsh trace stop | Out-Null
    &netsh wfp capture stop | Out-Null
	start-Sleep 2
	&ipconfig /flushdns | Out-Null
	&netsh interface ip delete arpcache | Out-Null
	start-sleep 1
    $NetshProcess = Get-Process | Where-Object { $_.Name -eq "netsh" } -ErrorAction SilentlyContinue
    if ($NetshProcess -ne $null) {
		foreach ($process in $NetshProcess) {stop-Process $process}
    }
    if ($buildNumber -le 7601) {
		&netsh trace start overwrite=yes capture=yes scenario=InternetClient report=yes maxSize=500 traceFile=$traceFile fileMode=circular | Out-Null
	}
	else {
		&netsh trace start overwrite=yes capture=yes scenario=InternetClient_dbg report=yes maxSize=500 traceFile=$traceFile fileMode=circular | Out-Null
	}
    &netsh advfirewall set allprofiles logging allowedconnections enable   # enable firewall logging for allowed traffic
    &netsh advfirewall set allprofiles logging droppedconnections enable   # enable firewall logging for dropped traffic
    Start-Process -WindowStyle hidden netsh.exe -WorkingDirectory "$resultOutputDir\NetTraces" -ArgumentList "wfp capture start file=wfpdiag.cab keywords=19" # start capturing  WFP log
	Start-PSRRecording
	&netstat -anob | Out-File "$resultOutputDir\NetTraces\NetStatOutputAtStart.txt"
	"Netstat output above was taken at: " + (Get-Date) | Out-File "$resultOutputDir\NetTraces\NetStatOutputAtStart.txt" -Append
	if ($OSPreviousVersion) {
		$OMSPath = "$env:ProgramFiles\Microsoft Monitoring Agent\Agent\Tools"
		if (Test-Path -path $OMSPath) {
			$MMAPathExists = "True"
			Get-Service HealthService | Stop-Service -ErrorAction SilentlyContinue
			&$OMSPath\StopTracing.cmd | Out-Null
			&$OMSPath\StartTracing.cmd VER | Out-Null
			Get-Service HealthService | Start-Service -ErrorAction SilentlyContinue
		}
	}
    $MinutesToRun = Get-MinutesValue
    StartTimer
	Stop-Wpr
    Write-Host "Note: Stopping network and wfp traces may take a while..."
	&netstat -anob | Out-File "$resultOutputDir\NetTraces\NetStatOutputAtStop.txt"
	"Netstat output above was taken at: " + (Get-Date) | Out-File "$resultOutputDir\NetTraces\NetStatOutputAtStop.txt" -Append
    &netsh wfp capture stop
	Stop-PSRRecording
    &netsh trace stop
	&netsh advfirewall set allprofiles logging allowedconnections disable   # disable firewall logging for allowed traffic
    &netsh advfirewall set allprofiles logging droppedconnections disable   # disable firewall logging for dropped traffic
	Copy-Item $env:SystemRoot\system32\LogFiles\Firewall\pfirewall.log -Destination "$resultOutputDir\NetTraces\" -ErrorAction SilentlyContinue
	if ($MMAPathExists) { 
		&$OMSPath\StopTracing.cmd | Out-Null
		Copy-Item $env:SystemRoot\Logs\OpsMgrTrace\* -Destination "$resultOutputDir\NetTraces\" -ErrorAction SilentlyContinue
	}
	Get-DefenderAV
	if (!$OSPreviousVersion) {
		$PSExecCommand = Join-Path $outputDir "PsExec.exe"
		&$PSExecCommand -accepteula -s robocopy $env:ProgramData\Microsoft\Diagnosis "$resultOutputDir\NetTraces\Diagnosis" /E /ZB /w:1 /r:1
	}
	Get-ChildItem HKLM:\SOFTWARE\microsoft\windows\currentversion\diagnostics -recurse | Out-File "$resultOutputDir\SystemInfoLogs\DiagTrackReg.txt"
	# Dump HOSTS file content to file
	Copy-Item $env:SystemRoot\System32\Drivers\etc\hosts -Destination "$resultOutputDir\SystemInfoLogs" -ErrorAction SilentlyContinue
}

# Define C# functions to extract info from Windows Security Center (WSC)
# WSC_SECURITY_PROVIDER as defined in Wscapi.h or http://msdn.microsoft.com/en-us/library/bb432509(v=vs.85).aspx
# And http://msdn.microsoft.com/en-us/library/bb432506(v=vs.85).aspx
$wscDefinition = @"
		[Flags]
        public enum WSC_SECURITY_PROVIDER : int
        {
            WSC_SECURITY_PROVIDER_FIREWALL = 1,				// The aggregation of all firewalls for this computer.
            WSC_SECURITY_PROVIDER_AUTOUPDATE_SETTINGS = 2,	// The automatic update settings for this computer.
            WSC_SECURITY_PROVIDER_ANTIVIRUS = 4,			// The aggregation of all antivirus products for this computer.
            WSC_SECURITY_PROVIDER_ANTISPYWARE = 8,			// The aggregation of all anti-spyware products for this computer.
            WSC_SECURITY_PROVIDER_INTERNET_SETTINGS = 16,	// The settings that restrict the access of web sites in each of the Internet zones for this computer.
            WSC_SECURITY_PROVIDER_USER_ACCOUNT_CONTROL = 32,	// The User Account Control (UAC) settings for this computer.
            WSC_SECURITY_PROVIDER_SERVICE = 64,				// The running state of the WSC service on this computer.
            WSC_SECURITY_PROVIDER_NONE = 0,					// None of the items that WSC monitors.
			
			// All of the items that the WSC monitors.
            WSC_SECURITY_PROVIDER_ALL = WSC_SECURITY_PROVIDER_FIREWALL | WSC_SECURITY_PROVIDER_AUTOUPDATE_SETTINGS | WSC_SECURITY_PROVIDER_ANTIVIRUS |
            WSC_SECURITY_PROVIDER_ANTISPYWARE | WSC_SECURITY_PROVIDER_INTERNET_SETTINGS | WSC_SECURITY_PROVIDER_USER_ACCOUNT_CONTROL |
            WSC_SECURITY_PROVIDER_SERVICE | WSC_SECURITY_PROVIDER_NONE
        }

        [Flags]
        public enum WSC_SECURITY_PROVIDER_HEALTH : int
        {
            WSC_SECURITY_PROVIDER_HEALTH_GOOD, 			// The status of the security provider category is good and does not need user attention.
            WSC_SECURITY_PROVIDER_HEALTH_NOTMONITORED,	// The status of the security provider category is not monitored by WSC. 
            WSC_SECURITY_PROVIDER_HEALTH_POOR, 			// The status of the security provider category is poor and the computer may be at risk.
            WSC_SECURITY_PROVIDER_HEALTH_SNOOZE, 		// The security provider category is in snooze state. Snooze indicates that WSC is not actively protecting the computer.
            WSC_SECURITY_PROVIDER_HEALTH_UNKNOWN
        }

		
        [DllImport("wscapi.dll")]
        private static extern int WscGetSecurityProviderHealth(int inValue, ref int outValue);

		// code to call interop function and return the relevant result
        public static WSC_SECURITY_PROVIDER_HEALTH GetSecurityProviderHealth(WSC_SECURITY_PROVIDER inputValue)
        {
            int inValue = (int)inputValue;
            int outValue = -1;

            int result = WscGetSecurityProviderHealth(inValue, ref outValue);

            foreach (WSC_SECURITY_PROVIDER_HEALTH wsph in Enum.GetValues(typeof(WSC_SECURITY_PROVIDER_HEALTH)))
                if ((int)wsph == outValue) return wsph;

            return WSC_SECURITY_PROVIDER_HEALTH.WSC_SECURITY_PROVIDER_HEALTH_UNKNOWN;
        }
"@

# Add-type to use SetForegroundWindow api https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setforegroundwindow
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 
Add-Type @"
  using System;
  using System.Runtime.InteropServices;
  public class WindowFocus {
     [DllImport("user32.dll")]
     [return: MarshalAs(UnmanagedType.Bool)]
     public static extern bool SetForegroundWindow(IntPtr hWnd);
  }
"@

function Get-DefenderAV{
	New-Item -ItemType Directory -Path "$resultOutputDir\DefenderAV" -ErrorAction SilentlyContinue | out-Null
	if (($WDVerboseTraceV) -and (!$OSPreviousVersion)) {
		&$MpCmdRunCommand -CaptureNetworkTrace
		start-Sleep 1
		Stop-MpCmdRunTrace
	}
	if ($MpCmdRunCommand) {
		&$MpCmdRunCommand -getfiles
		Move-Item -Path "$MpCmdResultPath\MpSupportFiles.cab" -Destination "$resultOutputDir\DefenderAV\"
		Move-Item -path "C:\Users\Public\Downloads\Capture.npcap" -Destination "$resultOutputDir\DefenderAV\" -ErrorAction SilentlyContinue
	}
	&fltmc instances -v "$env:SystemDrive" > $resultOutputDir\SystemInfoLogs\filters.txt
	if ($OSProductName.tolower() -notlike ("*server*"))  {
		Write-output "`r`n##################### Windows Security Center checks ######################" | Out-File $connectivityCheckFile -Append
		$wscType=Add-Type -memberDefinition $wscDefinition -name "wscType" -UsingNamespace "System.Reflection","System.Diagnostics" -PassThru
 
		"            Firewall: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_FIREWALL) | Out-File $connectivityCheckFile -Append
		"         Auto-Update: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_AUTOUPDATE_SETTINGS) | Out-File $connectivityCheckFile -Append
		"          Anti-Virus: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_ANTIVIRUS) | Out-File $connectivityCheckFile -Append
		"        Anti-Spyware: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_ANTISPYWARE) | Out-File $connectivityCheckFile -Append
		"   Internet Settings: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_INTERNET_SETTINGS) | Out-File $connectivityCheckFile -Append
		"User Account Control: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_USER_ACCOUNT_CONTROL) | Out-File $connectivityCheckFile -Append
		"         WSC Service: " + $wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_SERVICE) | Out-File $connectivityCheckFile -Append

		if ($wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_FIREWALL) -eq $wscType[2]::WSC_SECURITY_PROVIDER_HEALTH_POOR) {
			Write-output "Windows Defender firewall settings not optimal" | Out-File $connectivityCheckFile -Append
		}
		if ($wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_USER_ACCOUNT_CONTROL) -eq $wscType[2]::WSC_SECURITY_PROVIDER_HEALTH_POOR) {
			Write-output "User Account Controller (UAC) is switched off" | Out-File $connectivityCheckFile -Append
		}
		if ($wscType[0]::GetSecurityProviderHealth($wscType[1]::WSC_SECURITY_PROVIDER_ANTIVIRUS) -eq $wscType[2]::WSC_SECURITY_PROVIDER_HEALTH_GOOD) {
			Write-output "Windows Defender anti-virus is running and up-to-date" | Out-File $connectivityCheckFile -Append
		}
	}
}

function StartTimer {
	$timeout = New-TimeSpan -Minutes $MinutesToRun
	$sw = [diagnostics.stopwatch]::StartNew()
	$DiagTrackID = (TASKLIST /SVC /FI �"SERVICES eq diagtrack" /FO CSV | ConvertFrom-Csv).PID
	$NetConnection = {} | Select State,RequestedState,CreationTime,RemoteAddress | format-table -AutoSize
	if (!$OSPreviousVersion) {
		Write-output "##################### DiagTrack uploading route check #####################" | Out-File $connectivityCheckFile -Append
		Write-output "Connections identified from DiagTrack service will be listed below" | Out-File $connectivityCheckFile -Append
	}
	if (!$DiagTrackID) {
		Write-output "Could not find DiagTrack PID" | Out-File $connectivityCheckFile -Append 
    }
	if ($RemoteRun) {
		Write-Warning "The trace collection was initiated remotely. Please wait for data collection timer to complete."
	}
	while ($sw.elapsed -lt $timeout){
		Start-Sleep -Seconds 1
        $rem = $timeout.TotalSeconds - $sw.elapsed.TotalSeconds
		if ($RemoteRun) {
			Write-Host "Remaining seconds: " ([math]::Round($rem))
		} else {
			Write-Progress -Activity "Collecting traces, run your scenario now and press 'q' to stop data collection at any time" -Status "Progress:"  -SecondsRemaining $rem -PercentComplete (($sw.elapsed.Seconds/$timeout.TotalSeconds)*100)
		}
		if ($DiagTrackID -and !$OSPreviousVersion) {
			try {
                $NetConnection = Get-NetTCPConnection -AppliedSetting Internet | Where-Object OwningProcess -eq $DiagTrackID | select -Property State,RequestedState,CreationTime,RemoteAddress
				$NetConnections += $NetConnection
            }
            catch {
            }
		}
		if (!$RemoteRun) {
			if ([console]::KeyAvailable) {
				$key = [System.Console]::ReadKey() 
				if ( $key.key -eq 'q') {
					Write-Warning  "The trace collection action was ended by user exit command"
					break 
				}
			}
		}
    }
	$UniqueNetConnections = $NetConnections | Sort-Object CreationTime -Unique
	$UniqueNetConnections | Out-File $connectivityCheckFile -Append
}

function Get-MinutesValue {
	if ($RemoteRun) {
		"`r`nLog Collection was started from a remote machine." | Out-File $connectivityCheckFile -Append
		return $MinutesToRun
	} 
	else {
		try {
			[int]$MinutesToRun=(Read-Host "Enter the number of minutes to collect traces")
			return $MinutesToRun
		}
		catch {
			 Write-Warning  ($_.Exception.Message).split(':')[1]
			 return $MinutesToRun = $false
		}
	}
}

function StartTraces() {
    if ($netTrace) {
        netsh trace start capture=yes report=yes traceFile=$traceFile fileMode=single
    }
    if ($wfpTrace) {
        netsh advfirewall set allprofiles logging allowedconnections enable   # enable firewall logging for allowed traffic
        netsh advfirewall set allprofiles logging droppedconnections enable   # enable firewall logging for dropped traffic
        netsh wfp capture start keywords=19   # start capturing  WFP log
    }
 }

function Check-WptState($CheckCommand) {
	if (!$WDPerfTraceA) {
		$CheckCommand = "wpr.exe"
	}
	$buildNumber = ([System.Environment]::OSVersion).Version.build
	# This line will reload the path so that a recent installation of wpr will take effect immediately:
	$env:path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
	$command = Get-Command $CheckCommand -ErrorAction SilentlyContinue
	$SenseWprp7 =  Join-Path $outputDir "SenseW7.wprp"
	$SenseWprp10 = Join-Path $outputDir "SenseW10.wprp"
	$SenseWprp = Join-Path $outputDir "Sense.wprp"
	$DlZipFile = Join-Path $outputDir "WPT.cab"
	if ($command -eq $null){
		Write-Warning "Performance Toolkit is not installed on this machine. It is required for full traces to be collected."
		Write-host -ForegroundColor Green "Please wait while we download WPT installer files (~50Mb) to MDATPClientAnalyzer directory. Refer to https://aka.ms/adk for more information about the 'Windows ADK'."
		$WPTURL = "https://aka.ms/MDATPWPT"
		Import-Module BitsTransfer
		$BitsResult = Start-BitsTransfer -Source $WPTURL -Destination "$DlZipFile" -TransferType Download -Asynchronous
		$DownloadComplete = $false
		if (!(Test-Path -path $DlZipFile)) {
			while ($DownloadComplete -ne $true) {
				start-Sleep 1
				$jobstate = $BitsResult.JobState;
				$percentComplete = ($BitsResult.BytesTransferred / $BitsResult.BytesTotal) * 100
				Write-Progress -Activity ('Downloading' + $result.FilesTotal + ' files') -Status "Progress:" -PercentComplete $percentComplete 
				if ($jobstate.ToString() -eq 'Transferred') {
				    $DownloadComplete = $true
					Write-Progress -Activity ('Downloading' + $result.FilesTotal + ' files') -Completed close 
				}
				if ($jobstate.ToString() -eq 'TransientError') {
                    $DownloadComplete = $true
                    Write-host "Unable to download ADK installation package."
                }
			}
		$BitsResult | complete-BitsTransfer
		}
		if (Test-Path -path "$DlZipFile") {
			#Expand-Archive CMDlet or System.IO.Compression.ZipFile does not work with some older PowerShell/OS combinations so using the below for backwards compatbility 
			&expand.exe "$DlZipFile" "`"$($outputDir.TrimEnd('\'))`"" -F:*
			Write-host -ForegroundColor Green "Download complete. Starting installer..."
			start-Sleep 1
			Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please click through the installer steps to deploy the Microsoft Windows Performance Toolkit (WPT) before proceeding"
			if ($buildNumber -eq 7601) {
				$AdkSetupPath = Join-Path $outputDir "8.0\adksetup.exe"
				Start-Process -wait -WindowStyle minimized "$AdkSetupPath" -ArgumentList "/ceip off /features OptionId.WindowsPerformanceToolkit"
				Read-Host "Press ENTER if intallation is complete and you are ready to resume..."	
			}
			elseif ($buildNumber -gt 7601) {
				$AdkSetupPath = Join-Path $outputDir "adksetup.exe"
				Start-Process -wait -WindowStyle minimized "$AdkSetupPath" -ArgumentList "/ceip off /features OptionId.WindowsPerformanceToolkit"
				Read-Host "Press ENTER if intallation is complete and you are ready to resume..."
			}
		}
		else {
			Write-host "Please download and install manually from https://aka.ms/adk" 
		}
		$env:path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
		$command = Get-Command $CheckCommand -ErrorAction SilentlyContinue
		if ($command -eq $null){
			Write-Host -BackgroundColor Red -ForegroundColor Yellow "WPT was not installed. Only partial data will be collected"
			return $WptState = "Missing"
		}
		elseif ($buildNumber -eq 7601) {
			Write-Warning "Note: Windows7/2008R2 machines also require running 'wpr.exe -disablepagingexecutive on' and rebooting"
			Write-Warning "To disable, run 'wpr.exe -disablepagingexecutive off' once data collection is complete"
			Read-Host "Press ENTER to allow MDATPClientAnalyzer to turn on 'disablepagingexecutive' and restart your Machine automatically"
			Start-Process -wait -WindowStyle minimized wpr.exe -ArgumentList "-disablepagingexecutive on"
			Restart-Computer -ComputerName .
		}
    }
	Write-Host "Stopping any running WPR trace profiles"
	Start-Process -wait -WindowStyle minimized wpr.exe -ArgumentList "-cancel" | out-Null
	if ($buildNumber -le 9600) {
		Copy-Item -path $SenseWprp7 -Destination $senseWprp -Force	
	}
	else {
		Copy-Item -path $SenseWprp10 -Destination $senseWprp -Force
	}		
	return $WptState = "Ready"
}

function Start-Wpr {
	if ($wprpTraceH -and $WptState -eq "Ready"){
		&wpr.exe -start GeneralProfile -start CPU -start FileIO -start DiskIO -start "$outputDir\Sense.wprp" -filemode 
	}
	elseif ($WptState -eq "Ready") {
		&wpr.exe -start "$outputDir\Sense.wprp" -filemode
	}
}

function Stop-Wpr {
    if ($WptState -eq "Ready") {
		&wpr.exe -stop $WprpTraceFile | Out-Null
	}
}

function Copy-RecentItems($ParentFolder, $DestFolderName) {
	$ParentFolder = (Get-ChildItem -Path $ParentFolder)
	$ParentFolder = ($ParentFolder | ? {$_.LastWriteTime -gt (Get-Date).AddDays(-2)} -ErrorAction SilentlyContinue)
	if ($ParentFolder -ne $null) {
		foreach ($subfolder in $ParentFolder) {
			Copy-Item -Recurse -Path $subfolder.FullName -Destination $resultOutputDir\$DestFolderName\$subfolder -ErrorAction SilentlyContinue
		}
	}
}

function Start-WinEventDebug($DebugLogName) {
    $log = New-Object System.Diagnostics.Eventing.Reader.EventLogConfiguration $DebugLogName
    $log.IsEnabled=$true
    $log.SaveChanges()
}

function Stop-WinEventDebug($DebugLogName) {
    $log = New-Object System.Diagnostics.Eventing.Reader.EventLogConfiguration $DebugLogName
    $log.IsEnabled=$false
    $log.SaveChanges()
    $DebugLogPath = [System.Environment]::ExpandEnvironmentVariables($log.LogFilePath)
    Copy-Item -path "$DebugLogPath" -Destination "$resultOutputDir\EventLogs\"
}

function SetLocalDumps() {
	# If already implementing LocalDumps as per https://docs.microsoft.com/en-us/windows/win32/wer/collecting-user-mode-dumps, then backup the current config
	if (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps") {
		&Reg export "HKLM\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" "C:\temp\regbackup.reg" /y 2>&1 | Out-Null
	}  
	Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -Recurse -ErrorAction SilentlyContinue | out-Null
	New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting" -Name "LocalDumps" -ErrorAction SilentlyContinue | out-Null
	New-Item -ItemType Directory -Path "$resultOutputDir\CrashDumps" -ErrorAction SilentlyContinue | out-Null
	New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -Name "DumpFolder" -Value "$resultOutputDir\CrashDumps" -PropertyType "ExpandString" -ErrorAction SilentlyContinue | out-Null
	New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -Name "DumpCount" -Value 5 -PropertyType DWord -ErrorAction SilentlyContinue | out-Null
	New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -Name "DumpType" -Value 2 -PropertyType DWord -ErrorAction SilentlyContinue | out-Null
}

function RestoreLocalDumps() {
	if (Test-Path "$outputDir\regbackup.reg") {
		$RegImport = (&reg import "$outputDir\regbackup.reg" 2>&1)
	} else {
		Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps" -ErrorAction SilentlyContinue | out-Null
	}
}

function Get-AppCompatTraces() {
	$ProcmonCommand = Join-Path $outputDir "Procmon.exe"
	& $ProcmonCommand -accepteula -terminate
	SetLocalDumps
	$WptState = Check-WptState
	Start-wpr
	Remove-Item $outputDir\*.pml -Force -ErrorAction SilentlyContinue
	$MinutesToRun =  Get-MinutesValue
	& $ProcmonCommand -accepteula -backingfile "$outputDir\procmonlog.pml" -nofilter -quiet -minimized 
	Start-PSRRecording
	Start-WinEventDebug Microsoft-Windows-WMI-Activity/Debug
	StartTimer
	& $ProcmonCommand -accepteula -terminate
	Start-Sleep 5
	Stop-PSRRecording
	Stop-Wpr
	if (Test-Path -Path  $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider%4Admin.evtx') {
		Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider%4Admin.evtx' -Destination $resultOutputDir\EventLogs\MdmAdmin.evtx
		Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider%4Operational.evtx' -Destination $resultOutputDir\EventLogs\MdmOperational.evtx -ErrorAction SilentlyContinue
	}
	Stop-WinEventDebug Microsoft-Windows-WMI-Activity/Debug
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-WMI-Activity%4Operational.evtx' -Destination $resultOutputDir\EventLogs\WMIActivityOperational.evtx
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\System.evtx' -Destination $resultOutputDir\EventLogs\System.evtx
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Application.evtx' -Destination $resultOutputDir\EventLogs\Application.evtx
	Get-DefenderAV
	Start-Sleep 5
	$procmonlogs = Get-Item $outputDir\*.pml
	$DestFolderName = "WER"
	Copy-RecentItems $env:ProgramData\Microsoft\Windows\WER\ReportArchive $DestFolderName
	Copy-RecentItems $env:ProgramData\Microsoft\Windows\WER\ReportQueue $DestFolderName
	Move-Item -Path $procmonlogs -Destination $resultOutputDir
	RestoreLocalDumps
}		

 function Stop-PerformanceCounters{
        param (
            $DataCollectorSet,
            $DataCollectorName
        )
        try{
            $DataCollectorSet.Query($DataCollectorName,$null)
            if($DataCollectorSet.Status -ne 0){
                $DataCollectorSet.stop($false)
                Start-Sleep 10
            }
           
            $DataCollectorSet.Delete()
        }
        catch [Exception] {
            $_.Exception.Message
        }
 }

 function Get-PerformanceCounters {
    param (
        [Alias("r")][switch]$RunCounter
    )

    $filePathToXml = "$outputDir\PerfCounter.xml"
        if($RunCounter){
                if (($buildNumber -eq 9600) -or ($buildNumber -eq 7601)){
                        Copy-Item  -path "$outputDir\PerfCounterW7.xml" -Destination  "$outputDir\PerfCounter.xml" -Force
                }
                else {
                        Copy-Item  -path "$outputDir\PerfCounterW10.xml"  -Destination  "$outputDir\PerfCounter.xml" -Force
                    }   
                $xmlContent = New-Object XML
                $xmlContent.Load($filePathToXml)
                $xmlContent.SelectNodes("//OutputLocation") | ForEach-Object {  $_."#text" = $_."#text".Replace('c:\',$outputDir) }
                $xmlContent.SelectNodes("//RootPath") | ForEach-Object {  $_."#text" = $_."#text".Replace('c:\',$outputDir) }
                $xmlContent.Save($filePathToXml)
    }

    $DataCollectorName = "MDATP-Perf-Counter"
    $DataCollectorSet = New-Object -COM Pla.DataCollectorSet
    [string]$xml = Get-Content $filePathToXml
    $DataCollectorSet.SetXml($xml)
	Write-Host "Stopping any running perfmon trace profiles"
    Stop-PerformanceCounters -DataCollectorSet  $DataCollectorSet -DataCollectorName $DataCollectorName
    if ($RunCounter){
        $DataCollectorSet.Commit("$DataCollectorName" , $null , 0x0003) | Out-Null
        $DataCollectorSet.Start($false)
    }
 }

function Get-PerformanceTraces() {
	$WPtState = Check-WptState
	if (!$RemoteRun) {
		$MinutesToRun = $null
	}
	while (![int]$MinutesToRun){
        $MinutesToRun =  Get-MinutesValue
    }
    if ($wprpTraceL) {
		Get-PerformanceCounters -r
		Start-Wpr
		StartTimer
	}
    elseif  ($wprpTraceH) {
	 	Start-Wpr
		StartTimer
    }			
	Stop-Wpr
    if ($wprpTraceL) {
        Get-PerformanceCounters
    }
	Get-DefenderAV
	$Perfmonlogs = Get-Item $outputDir\*.blg
    if (($Perfmonlogs) -ne $null) {
		Move-Item -Path $Perfmonlogs -Destination $resultOutputDir
    } 
}

function StopTraces() {
    if ($netTrace) {
        netsh trace stop
    }
    if ($wfpTrace) {
        netsh wfp capture stop
        Move-Item -Path $PSScriptRoot\wfpdiag.cab -Destination $resultOutputDir
        Copy-Item $env:SystemRoot\system32\LogFiles\Firewall\pfirewall.log -Destination $resultOutputDir
    }
}

function SetUrlList {
    param (
        [parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]$OSPreviousVersion
    )
    $regionInfos = @{
        US=@{cnc1='eus'; cnc2='cus'; vortex='us'};
        EU=@{cnc1='neu'; cnc2='weu'; vortex='eu'};
        UK=@{cnc1='ukw'; cnc2='uks'; vortex='uk'};
        FFL4=@{cnc1='usgv'; cnc2='usgt'; vortex='us4'};
        FFL5=@{cnc1='usde'; cnc2='usdc'; vortex='us5'};
    }
    $cncUrl = "https://winatp-gw-ToReplace.microsoft.com/test"
    $vortexUrl = "https://ToReplace.vortex-win.data.microsoft.com/health/keepalive"
    $vortexUrlv20 = "https://ToReplace-v20.events.data.microsoft.com/ping"
	$DiagTrackSettingsUrl = "https://settings-win.data.microsoft.com/qos"
    if (Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection" -Value OnboardingInfo ){
        $Region = (((Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\").OnboardingInfo | ConvertFrom-Json).body | ConvertFrom-Json).vortexGeoLocation
        Clear-Content -Path $EndpointList
        Add-Content $EndpointList -value $cncUrl.Replace('ToReplace',$regionInfos.($Region).cnc1)
        Add-Content $EndpointList -value $cncUrl.Replace('ToReplace',$regionInfos.($Region).cnc2)
		Add-Content $EndpointList -value $DiagTrackSettingsUrl
        if (($Region) -notmatch 'FFL'){
            # Exist only for not FF tenants
                Add-Content $EndpointList -value $vortexUrl.Replace('ToReplace',$regionInfos.($Region).vortex)
                Add-Content $EndpointList -Value "http://ctldl.windowsupdate.com/msdownload/update/v3/static/trustedr/en/disallowedcertstl.cab	NoPinning"
            }
            Add-Content $EndpointList -value $vortexUrlv20.Replace('ToReplace',$regionInfos.($Region).vortex)
    }
    elseif ($OSPreviousVersion) {
        Clear-Content -Path $EndpointList
        $Regions = ('US','UK','EU')
         foreach ($Region in $Regions){
            Add-Content $EndpointList -value $cncUrl.Replace('ToReplace',$regionInfos.($Region).cnc1)
            Add-Content $EndpointList -value $cncUrl.Replace('ToReplace',$regionInfos.($Region).cnc2)
        }
    }
}

function CheckConnectivity { param (
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$OSPreviousVersion,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$connectivityCheckFile,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$connectivityCheckUserFile
    )

    [version]$mindotNet="4.0.30319"
    
    SetUrlList -OSPreviousVersion $OSPreviousVersion

    if ((Get-RegistryValue -Path  "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Client" -Value Version)) {
        [version]$dotNet = Get-RegistryValue -Path  "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Client" -Value Version
    } else {
        [version]$dotNet = "0.0.0000"
    }

    if (!$OSPreviousVersion) {
        StartTraces        
		$MDATPClientAnalyzerCommand = Join-Path $outputDir "MDATPClientAnalyzer.exe"
		$whoami = (&whoami.exe)

		# check if running with system context (i.e. script was most likely run remotely via "psexec.exe -s \\machine command")
        if ($whoami -eq "nt authority\system"){
			"`r`nConnectivity output, running as System:" | Out-File $connectivityCheckFile -Append
			&$MDATPClientAnalyzerCommand >> $connectivityCheckFile
        } else {
			"`r`nConnectivity output, running psexec -s using $whoami :" | Out-File $connectivityCheckFile -Append
			Write-Host "The tool checks connectivity to Microsoft Defender ATP service URLs. This may take longer to run if URLs are blocked."
			& ($PSScriptRoot + "\PsExec.exe") -accepteula -s -w "$PSScriptRoot" "$MDATPClientAnalyzerCommand" -p $manualProxy >> $connectivityCheckFile
		}
        # Run the tool as interactive user (for authenticated proxy scenario)
        &$MDATPClientAnalyzerCommand -p $manualProxy > $connectivityCheckUserFile
        StopTraces
    }
    elseif ($dotNet -ge $mindotNet) {
        StartTraces

        $PSExecCommand = Join-Path $outputDir "PsExec.exe"
		Write-Host "The tool checks connectivity to Microsoft Defender ATP service URLs. This may take longer to run if URLs are blocked."
        $MDATPClientAnalyzerPreviousVersionCommand = Join-Path $outputDir "MDATPClientAnalyzerPreviousVersion.exe"
            
        $Global:connectivityresult = (& $PSExecCommand -accepteula -s -w "`"$($outputDir.TrimEnd('\'))`"" "$MDATPClientAnalyzerPreviousVersionCommand" )
        # Run the tool as interactive user (for authenticated proxy scenario)
        $Global:connectivityresultUser = (& $MDATPClientAnalyzerPreviousVersionCommand)
            
        #Run MMA Connectivity tool
        $MMARootFolder = "$env:ProgramFiles\Microsoft Monitoring Agent\Agent"
        if(Test-Path -path $MMARootFolder){
            $Global:TestOMSResult = & $MMARootFolder\TestCloudConnection.exe 
        }

        StopTraces
    } else {
        Write-Host -BackgroundColor Red -ForegroundColor Yellow "To run URI validation tool please install .NET framework 4.0  or higher"
            "To run URI validation tool please install .NET framework 4.0 or higher" | Out-File $connectivityCheckFile -Append
        $Global:connectivityresult = $false
        $Global:connectivityresultUser = $false
        $Global:TestOMSResult = $false
    }

    if ('$env:SystemRoot\\System32\wintrust.dll') {
        [version]$wintrustMinimumFileVersion = '6.1.7601.23971'
        $wintrustprops = @{
            Message = ""
            Valid = $true
            Version = [string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).ProductMajorPart +'.' +[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).ProductMinorPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).ProductBuildPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).FilePrivatePart
        }
        $Global:wintrustdll = new-object psobject -Property $wintrustprops

        if (([version]$Global:wintrustdll.version -lt $wintrustMinimumFileVersion) ) {
            $Global:wintrustdll.Valid = $false
            $Global:wintrustdll.Message = "######################################### Environment is not supported: "+[System.Environment]::OSVersion.VersionString+ " ################# `nMDATP can't start - it requires wintrust.dll version $wintrustMinimumFileVersion or higher, while this machine has version " + $wintrustdll.version + ". `n" `
                +"You should install one of the following updates:`n" `
                +"* KB4057400 - 2018-01-19 preview of monthly rollup.`n" `
                +"* KB4074598 - 2018-02-13 monthly rollup.`n" `
                +"* A later monthly rollup that supersedes them.`n" `
                +"#########################################################################################################################"
        } else {
            $Global:wintrustdll.Message = "The version " +$Global:wintrustdll.version +" of wintrust.dll is supported"
        }
    }

    if (('$env:SystemRoot\\System32\tdh.dll')) {
        [version]$gdrTdhMinimumFileVersion = '6.1.7601.18939'
        [version]$ldrMinimumFileVersion = '6.1.7601.22000'
        [version]$ldrTdhMinimumFileVersion = '6.1.7601.23142'
        $tdhprops = @{
            Message = ""
            Valid = $true
            Version = [string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).ProductMajorPart +'.' +[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).ProductMinorPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).ProductBuildPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).FilePrivatePart
        }
        $Global:tdhdll = new-object psobject -Property $tdhprops

        if ([version]$Global:tdhdll.Version -lt $gdrTdhMinimumFileVersion) {
            $Global:tdhdll.Valid = $false
            $Global:tdhdll.Message =  "######################################### Environment is not supported: "+[System.Environment]::OSVersion.VersionString+ " ################# `nMDATP can't start - it requires tdh.dll version $gdrTdhMinimumFileVersion or higher, while this machine has version " + $tdhdll.version + ". `n" `
                +"You should install the following update:`n" `
                +"* KB3080149 - Update for customer experience and diagnostic telemetry.`n" `
                +"#########################################################################################################################"
        }
        elseif ([version]$Global:tdhdll.Version -ge $ldrMinimumFileVersion -and [version]$tdhdll.Version -lt $ldrTdhMinimumFileVersion) {
            $Global:tdhdll.Valid = $false
            $Global:tdhdll.Message =  "######################################### Environment is not supported: "+[System.Environment]::OSVersion.VersionString+ " ################# `nMDATP can't start - it requires tdh.dll version $ldrTdhMinimumFileVersion or higher, while this machine has version " + $tdhdll.version + ". `n" `
                +"You should install the following update:`n" `
                +"* KB3080149 - Update for customer experience and diagnostic telemetry.`n" `
                +"#########################################################################################################################"
        } else {
            $Global:tdhdll.Message = "The version " +$Global:tdhdll.version +" of tdh.dll is supported"
        }
    }

    $protocol = [Enum]::ToObject([System.Net.SecurityProtocolType], 3072)
    [string]$global:SSLProtocol = $null
    try {
        [System.Net.ServicePointManager]::SecurityProtocol = $protocol
    } catch [System.Management.Automation.SetValueInvocationException] {
        $global:SSLProtocol = "`n############################################ Environment is not supported , the missing KB must be installed ##################`n"`
            +"Environment is not supported: " +[System.Environment]::OSVersion.VersionString+", MDATP requires TLS 1.2 support in .NET framework 3.5.1, exception "+$_.Exception.Message +" . You should install the following updates:`n" `
            +"* KB3154518 - Support for TLS System Default Versions included in the .NET Framework 3.5.1 on Windows 7 SP1 and Server 2008 R2 SP1`n"`
            +"* .NET framework 4.0 or later.`n"`
            +"########################################################################################################################" 
    } Catch [Exception] {
        $global:SSLProtocol = $_.Exception.Message
    }
}

function TestASRRules() {
    #Taken from: https://docs.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/attack-surface-reduction#block-process-creations-originating-from-psexec-and-wmi-commands
    $ASRRuleBlockPsExec = "d1e49aac-8f56-4280-b9ba-993a6d77406c"

	$ASRRules = (Get-MpPreference).AttackSurfaceReductionRules_Ids
	$ASRActions = (Get-MpPreference).AttackSurfaceReductionRules_Actions
	if (($ASRRules) -and ($ASRActions)){
		Write-output "############################ ASR rule check ###############################" | Out-File $connectivityCheckFile -Append
		# Check for existance of 'Block' mode ASR rule that can block PsExec from running
        $RuleIndex = $ASRRules::indexof($ASRRules,$ASRRuleBlockPsExec)
		if (($RuleIndex -ne -1) -and ($ASRActions[$RuleIndex] -eq 1)) {
			# Check if exclusions on script path are set
			$ASRRulesExclusions = (Get-MpPreference).AttackSurfaceReductionOnlyExclusions
			if (($ASRRulesExclusions) -and (($ASRRulesExclusions -contains $PSScriptRoot + '\') -or ($ASRRulesExclusions -contains $PSScriptRoot))) {
				"ASR rule 'Block process creations originating from PSExec and WMI commands' exists in block mode, but script path is excluded as needed" | Out-File $connectivityCheckFile -Append
                Write-Host -BackgroundColor Green -ForegroundColor black "Script path is excluded from ASR rules so URL checks can run as expected."
			} 
            else {
                "ASR rule 'Block process creations originating from PSExec and WMI commands' exists on the machine and is in Block mode" | Out-File $connectivityCheckFile -Append
			    Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please note that ASR rule 'Block process creations originating from PSExec and WMI commands' is enabled and can block this tool from performing network validation if no exclusion is set" 			
            }
		}
	}
}

#This function expects to receive the EventProvider, EventId and Error string and returns the error event if found
function Get-MatchingEvent($EventProvider, $EventID, $ErrorString) {
	$event = Get-WinEvent -ProviderName $EventProvider -MaxEvents 1000 -ErrorAction SilentlyContinue `
	| Where-Object -Property Id -eq $EventID `
	| ? {$_.Properties.Value -like "*$ErrorString*"} `
	| Select-Object -L 1

	return $EventError = $event;
}

function CheckProxySettings() {
	New-PSDrive HKU Registry HKEY_USERS -ErrorAction SilentlyContinue | Out-Null		
	$RegPathHKLM = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings"
	$RegPathHKU = "HKU:\S-1-5-18\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings"
	$RegPathHKCU = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings"

	if (Get-RegistryValue -Path $RegPathHKLM -Value "ProxyServer") {
		"Proxy settings in machine level were detected" | Out-File $connectivityCheckFile -append
		"The detected Proxy settings in machine path (HKLM) are :  " + (Get-RegistryValue -Path $RegPathHKLM -Value "ProxyServer" ) | Out-File $connectivityCheckFile -append
	} 
	
	if (Get-RegistryValue -Path $RegPathHKU -Value "ProxyServer") {
	    "Proxy settings in SYSTEM SID level were detected" | Out-File $connectivityCheckFile -append
	    "The detected proxy settings in SYSTEM HKU path (S-1-5-18) are :  " + (Get-RegistryValue -Path $RegPathHKU -Value "ProxyServer" ) | Out-File $connectivityCheckFile -append
	} 

	if (Get-RegistryValue -Path $RegPathHKCU -Value "ProxyServer") {
	    "Proxy setting in current user level were detected" | Out-File $connectivityCheckFile -append
		"The detected proxy settings in current user path (HKCU) are :  "+ (Get-RegistryValue -Path $RegPathHKCU -Value "ProxyServer" ) | Out-File $connectivityCheckFile -append	    
	}
}

function Get-InstalledPrograms($uninstallKeys) {
    $programsArray = $uninstallKeys | % { New-Object PSObject -Property @{
        DisplayName = $_.GetValue("DisplayName")
        DisplayVersion = $_.GetValue("DisplayVersion")
        InstallLocation = $_.GetValue("InstallLocation")
        Publisher = $_.GetValue("Publisher")
    }}
    $ProgramsArray | ? { $_.DisplayName }
}

function FormatTimestamp($TimeStamp) {
	if ($TimeStamp) {
		return ([DateTime]::FromFiletime([Int64]::Parse($TimeStamp))).ToString("U")
	} 
	else {
		return "Unknown"
	}
}

function Dump-ConnectionStatus {
	"Last SevilleDiagTrack LastNormalUploadTime TimeStamp: " + (FormatTimestamp($LastCYBERConnected)) | Out-File $connectivityCheckFile -append
	"Last SevilleDiagTrack LastRealTimeUploadTime TimeStamp: " + (FormatTimestamp($LastCYBERRTConnected)) | Out-File $connectivityCheckFile -append
    "Last SevilleDiagTrack LastInvalidHttpCode: " + $LastInvalidHTTPcode | Out-File $connectivityCheckFile -append
}
		
#Main
[int]$OSBuild = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value CurrentBuild
[string]$OSEditionID = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value EditionID
[string]$OSProductName =  Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value ProductName
[int]$PsMjVer = $PSVersionTable.PSVersion.Major

if (($OSBuild -le 7601) -And ($PsMjVer -le 2)) { 
	Write-Host -ForegroundColor Yellow "We recommend installing at least 'Windows Management Framework 3.0' (KB2506143) or later for optimal script results: `r`nhttps://www.microsoft.com/en-us/download/details.aspx?id=34595"
}

#Store paths for MpCmdRun.exe usage
if (Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WinDefend" -Value ImagePath) {
	$MsMpEngPath = Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WinDefend" -Value ImagePath
	[System.IO.DirectoryInfo]$CurrentMpCmdPath = $MsMpEngPath -replace "MsMpEng.exe" -replace """"
	$MpCmdRunCommand = Join-Path $CurrentMpCmdPath "MpCmdRun.exe"
	$MpCmdResultPath = "$env:ProgramData\Microsoft\Windows Defender\Support"
}
elseif (Test-Path -path "$env:ProgramFiles\Microsoft Security Client\MpCmdRun.exe") {
	$CurrentMpCmdPath = "$env:ProgramFiles\Microsoft Security Client\"
	$MpCmdRunCommand = "$env:ProgramFiles\Microsoft Security Client\MpCmdRun.exe"
	$MpCmdResultPath = "$env:ProgramData\Microsoft\Microsoft Antimalware\Support"
}

# Delete previous output if exists
if(Test-Path $resultOutputDir) {
    Remove-Item -Recurse -Force $resultOutputDir -ErrorVariable FileInUse;
    while ($FileInUse) {
        Write-Warning "Please close any opened log files from previous MDATPClientAnalyzer run and then try again."
        Read-Host "Press ENTER once you've closed all open files."
        Remove-Item -Recurse -Force $resultOutputDir -ErrorVariable FileInUse
    }
}
if(Test-Path $outputZipFile) {
    Remove-Item -Recurse -Force  $outputZipFile
}

# Create output folders
New-Item -ItemType directory -Path $resultOutputDir | Out-Null
New-Item -ItemType Directory -Path "$resultOutputDir\EventLogs" | out-Null
New-Item -ItemType Directory -Path "$resultOutputDir\SystemInfoLogs" | out-Null

"Script Version: " + $ScriptVer | Out-File $connectivityCheckFile -append
Write-output "############################ Machine Info summary ####################################" | Out-File $connectivityCheckFile -append
$MinorBuild = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\" -Value "UBR" )
"Machine Operating System: " + $OSProductName | Out-File $connectivityCheckFile -append
"Machine build number: " + [System.Environment]::OSVersion.VersionString + " Minor build number: " + $MinorBuild | Out-File $connectivityCheckFile -append
if ((($OSBuild -ge 7601 -and $OSBuild -le 14393) -and ($OSProductName -notmatch 'Windows 10')) -and (($OSEditionID -match 'Enterprise') -or ($OSEditionID -match 'Pro') -or ($OSEditionID -match 'Ultimate') -or ($OSEditionID -match 'Server'))) {
    $OSPreviousVersion = $true
	if (Test-Path -path "$env:ProgramFiles\Microsoft Monitoring Agent\Agent\HealthService.dll") {
		$HealthServiceDll = "$env:ProgramFiles\Microsoft Monitoring Agent\Agent\HealthService.dll"
		$HealthServiceVersion = [string]((Get-ItemProperty -Path "$HealthServiceDll").VersionInfo).ProductMajorPart +'.' +[string]((Get-ItemProperty -Path "$HealthServiceDll").VersionInfo).ProductMinorPart +'.'+[string]((Get-ItemProperty -Path "$HealthServiceDll").VersionInfo).ProductBuildPart +'.'+[string]((Get-ItemProperty -Path "$HealthServiceDll").VersionInfo).FilePrivatePart
		"Health Service DLL version is: "+$HealthServiceVersion | Out-File $connectivityCheckFile -append
	}
    CheckConnectivity -OSPreviousVersion $OSPreviousVersion -connectivityCheckFile $connectivityCheckFile -connectivityCheckUserFile $connectivityCheckUserFile
      
    if ($Global:tdhdll.Valid -and $Global:wintrustdll.Valid -and !($global:SSLProtocol)) {
        "OS Environment is  supported: "+[System.Environment]::OSVersion.VersionString | Out-File $connectivityCheckFile -append
    } else {
        "OS Environment is not  supported: "+[System.Environment]::OSVersion.VersionString + " More information below" | Out-File $connectivityCheckFile -append
    }

    if ($Global:connectivityresult -match "failed" ) {
        "Command and Control channel as System Account : Some of the MDATP APIs failed , see details below" | Out-File $connectivityCheckFile -append
    } elseif (!$Global:connectivityresult) {
        "Command and Control channel as System Account: Not tested" | Out-File $connectivityCheckFile -append 
    } else {
        "Command and Control channel as System Account: Passed validation" | Out-File $connectivityCheckFile -append 
    }

    if ($Global:connectivityresultUser -match "failed" ) {
        "Command and Control channel as User Account : Some of the MDATP APIs failed , see details below" | Out-File $connectivityCheckFile -append
    } elseif (!$Global:connectivityresultUser) {
        "Command and Control channel as User Account: Not tested" | Out-File $connectivityCheckFile -append 
    } else {
        "Command and Control channel as User Account: Passed validation" | Out-File $connectivityCheckFile -append 
    }

    if ($Global:TestOMSResult -match "Connection failed" -or $Global:TestOMSResult -match "Blocked Host") {
        "OMS channel : Some of the OMS APIs failed , see details below" | Out-File $connectivityCheckFile -append
    } elseif (!$Global:TestOMSResult) {
        "OMS channel: Not tested" | Out-File $connectivityCheckFile -append 
    } else {
        "OMS channel:  Passed validation" | Out-File $connectivityCheckFile -append 
    }

    if ((Get-RegistryValue -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\" -Value "senseId")) {
        "Sense ID is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\" -Value "senseId" ) | Out-File $connectivityCheckFile -append
		"Sense OrgID is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value "OrgID" ) | Out-File $connectivityCheckFile -append
		$LastCnCConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status" -Value LastConnected)
		if ($LastCnCConnected) {
			"Last Sense Seen TimeStamp: " + (FormatTimestamp($LastCnCConnected)) | Out-File $connectivityCheckFile -append
		}
        "Service Microsoft Monitoring Agent is " + (Get-Service -Name HealthService -ErrorAction SilentlyContinue).Status | Out-File $connectivityCheckFile -append
        "Sense Configuration Version is : " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status" -Value "ConfigurationVersion" ) | Out-File $connectivityCheckFile -append
    } else {
        "Machine is: not onboarded" | Out-File $connectivityCheckFile -append
    }

	if (Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\services\HealthService\Parameters")  {
		Get-ChildItem HKLM:\SYSTEM\CurrentControlSet\services\HealthService\Parameters -recurse | Format-table -AutoSize | Out-File "$resultOutputDir\SystemInfoLogs\HealthServiceReg.txt"
		# Test if multiple MMA workspaces are configured
		$AgentCfg = New-Object -ComObject AgentConfigManager.MgmtSvcCfg
		$workspaces = $AgentCfg.GetCloudWorkspaces()
		if ($workspaces.Item(1)) {
			Write-output "`r`n############################ Multiple workspaces check ###############################" | Out-File $connectivityCheckFile -Append
			Write-Warning "Please note the machine has multiple MMA workspaces. If the machine is onboarded via ASC (Azure Security Center), then it is recommended to remove the MDATP workspace to avoid cyber upload issues" 
			Write-output "Machine has more than one workspace. If assigned to ASC workspace then it is recommended to remove the MDATP workspace" | Out-File $connectivityCheckFile -Append
		}
	}

    Write-output "##########################################################################" | Out-File $connectivityCheckFile -append  
} else {
    if ((Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value OnboardingState ) -eq $True) {
        "Machine is: onboarded" | Out-File $connectivityCheckFile -append
		$IsOnboarded = $True
		$SenseId = (Get-WinEvent -ProviderName Microsoft-Windows-SENSE -ErrorAction SilentlyContinue | Where-Object -Property Id -eq 13 | Sort-Object -Property TimeCreated | Select-Object -L 1).Message
		if ($SenseId -eq $null) {
			$SenseId = (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\Windows Advanced Threat Protection" -Value "SenseId" )
			"Windows Defender Advanced Threat Protection machine ID: " + 	$SenseId | Out-File $connectivityCheckFile -append
		} else {
			$SenseId | Out-File $connectivityCheckFile -append
		}
        "Sense GUID is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection" -Value "senseGuid" ) | Out-File $connectivityCheckFile -append
        "Sense OrgID is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value "OrgID" ) | Out-File $connectivityCheckFile -append
        "Sense service state is: " + (Get-Service -Name Sense).Status | Out-File $connectivityCheckFile -append
        "UTC service state is: " + (Get-Service -Name DiagTrack).Status | Out-File $connectivityCheckFile -append
        "Defender service state is: " + (Get-Service -Name WinDefend).Status | Out-File $connectivityCheckFile -append
        "Microsoft Account Sign-in Assistant service start type is: " + (Get-Service -Name wlidsvc).StartType | Out-File $connectivityCheckFile -append
        if (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender" -Value "PassiveMode") {
                $AVPassiveMode = $true
                "Windows Defender is in passive mode" | Out-File $connectivityCheckFile -append
        }
        "Windows Defender AV Signature Version is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Signature Updates" -Value "AVSignatureVersion" )  + "  Engine Version is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Signature Updates" -Value "EngineVersion" )  | Out-File $connectivityCheckFile -append
        $LastCnCConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status" -Value LastConnected)
		if ($LastCnCConnected) {
			"Last Sense Seen TimeStamp: " + (FormatTimestamp($LastCnCConnected)) | Out-File $connectivityCheckFile -append
		}

        if ($IsOnboarded) {
			if ($OSBuild -eq 14393) {
				$LastCYBERConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\SevilleSettings" -Value LastNormalUploadTime)
				$LastCYBERRTConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\SevilleSettings" -Value LastRealTimeUploadTime)
				$LastInvalidHTTPcode = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\HeartBeats\Seville" -Value LastInvalidHttpCode)
				Dump-ConnectionStatus 
			} elseif ($OSBuild -le 17134) {
				$LastCYBERConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-WDATP" -Value LastNormalUploadTime)
				$LastCYBERRTConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-WDATP" -Value LastRealTimeUploadTime)
				$LastInvalidHTTPcode = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\HeartBeats\Seville" -Value LastInvalidHttpCode)
				Dump-ConnectionStatus
			} elseif ($OSBuild -ge 17763) {
				$LastCYBERConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\TelLib" -Value LastSuccessfulNormalUploadTime)
				$LastCYBERRTConnected = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\TelLib" -Value LastSuccessfulRealtimeUploadTime)
				$LastInvalidHTTPcode = (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\TelLib\HeartBeats\Seville" -Value LastInvalidHttpCode)
				Dump-ConnectionStatus
			}
		}


		# Test for events indicating expired OrgID in Sense event logs
		if (!$OSPreviousVersion) {
			$EventError = Get-MatchingEvent Microsoft-Windows-SENSE 67 "400"
			if ($EventError -eq $null) {
				$EventError = Get-MatchingEvent Microsoft-Windows-SENSE 5 "400"
			}
			if ($EventError -ne $null) {
				Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please note the machine is reporting to an expired OrgID:"
				Write-Host (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value "OrgID" )
				Write-host -BackgroundColor Red -ForegroundColor Yellow "Please Offboard this machine prior to re-onboarding."
				Write-Host "Contact Microsoft Support if you don't have access to the offboarding script with the above mentioned OrgID"
				Write-Host "Note: To view the current OrgID, please go to the MDATP portal (securitycenter.microsoft.com) and click on the user name in the top right corner."
				Write-Warning "If you have already fixed the issue and the above OrgId matches your securitycenter portal info, you can clear the event log by running the below command as admin:"
				Write-Host -ForegroundColor Green "wevtutil clear-log Microsoft-Windows-SENSE/Operational"
				Write-output "`r`n############################ OrgID error check ###############################" | Out-File $connectivityCheckFile -Append
				Write-output "Please note the machine is reporting to an expired OrgID:" | Out-File $connectivityCheckFile -Append
				Write-output (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value "OrgID" ) | Out-File $connectivityCheckFile -Append
				write-output "Event Log error information:" | Out-File $connectivityCheckFile -Append
				$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
			}
		}

    } else {
        "Machine is: not onboarded" | Out-File $connectivityCheckFile -append
    }

	# Dump Registry OnboardingInfo if exists
	$RegOnboardingInfo = Get-RegistryValue "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\" -Value OnboardingInfo 
	$RegOnboardedInfo = Get-RegistryValue "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\" -Value OnboardedInfo 
	if (($RegOnboardingInfo -eq $False) -or ($RegOnboardingInfo -eq $null)) {
		"`r`Note: OnboardingInfo could not be found in the registry. This can be expected if machine was offboarded or onboarding was not yet executed." | Out-File $connectivityCheckFile -Append
	} else {
		($RegOnboardingInfo | ConvertFrom-Json).body | Out-File "$resultOutputDir\SystemInfoLogs\RegOnboardingInfoPolicy.Json"
		($RegOnboardedInfo | ConvertFrom-Json).body | Out-File "$resultOutputDir\SystemInfoLogs\RegOnboardedInfoCurrent.Json"
	}

    CheckConnectivity -OSPreviousVersion $OSPreviousVersion -connectivityCheckFile $connectivityCheckFile -connectivityCheckUserFile $connectivityCheckUserFile
    Write-output "##########################################################################" | Out-File $connectivityCheckFile -append
}



Write-output " " | Out-File $connectivityCheckFile -append
if ((($OSBuild -ge 7601 -and $OSBuild -le 14393) -and ($OSProductName -notmatch 'Windows 10')) -and (($OSEditionID -match 'Enterprise') -or ($OSEditionID -match 'Pro') -or ($OSEditionID -match 'Ultimate') -or ($OSEditionID -match 'Server'))) {
    "###################### OS validation  details  ############" | Out-File $connectivityCheckFile -append
    $Global:tdhdll.Message  | Out-File $connectivityCheckFile -append
    $Global:wintrustdll.Message  | Out-File $connectivityCheckFile -append
    $global:SSLProtocol | Out-File $connectivityCheckFile -append
    Write-output "##########################################################################`n" | Out-File $connectivityCheckFile -append  
    "###################### Connectivity details for Command and Control  validation  ############" | Out-File $connectivityCheckFile -append
    $connectivityresult | Out-File $connectivityCheckFile -append
    $Global:connectivityresultUser  | Out-File $connectivityCheckFile -append
    Write-output "##########################################################################`n" | Out-File $connectivityCheckFile -append  
    "###################### Connectivity details for OMS  validation  ############" | Out-File $connectivityCheckFile -append
    $Global:TestOMSResult | Out-File $connectivityCheckFile -append
    Write-output "##########################################################################`n" | Out-File $connectivityCheckFile -append  
}

if (!$OSPreviousVersion) {
	Write-output "`r`n######################## Defender AntiVirus cloud service check #########################" | Out-File $connectivityCheckFile -Append
	if ($MpCmdRunCommand) {
		&$MpCmdRunCommand -ValidateMapsConnection | Out-File $connectivityCheckFile -append
	}
}

"`r`n############## Connectivity Check for ctldl.windowsupdate.com #############" | Out-File $connectivityCheckFile -append
$urlctldl =  "http://ctldl.windowsupdate.com/msdownload/update/v3/static/trustedr/en/pinrulesstl.cab"
$webRequest = [net.WebRequest]::Create("$urlctldl")
try {
    "StatusCode for " + $urlctldl + " IS : " + $webRequest.GetResponse().StatusCode | Out-File $connectivityCheckFile -append
} catch [System.Net.WebException] {
    "StatusCode for "+ $urlctldl+ " IS : " + $_.Exception.Response.StatusCode + $_.Exception.Response.StatusCode.Value__ | Out-File $connectivityCheckFile -append
}

Write-output " " | Out-File $connectivityCheckFile -append
"########################### PROXY SETTINGS ################################" | Out-File $connectivityCheckFile -append
 CheckProxySettings

(netsh winhttp show proxy) | Out-File $connectivityCheckFile -append

#Collect Performance traces if flagged
if ($wprpTraceL -or $wprpTraceH) {
	Get-PerformanceTraces
}

elseif ($AppCompatC) {
	Get-AppCompatTraces
}

elseif ($NetTraceI) {
	Get-NetTraces
}

elseif ($WDPerfTraceA) {
	Get-WdAvPerfTrace
}

elseif ($WDVerboseTraceV) {
	Get-WdAvVerboseTrace
}

elseif ($BootTraceB) {
	Set-BootTraces
}

if ($CrashDumpD) {
	Get-CrashDumps
}

if ($FullCrashDumpZ) {
	Set-CrashOnCtrlScroll
	Set-FullCrashDump
	Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please reboot the machine for the change in settings to apply" 
	Write-Host -ForegroundColor Green "To force the system to crash for memory dump collection, hold down the RIGHT CTRL key while pressing the SCROLL LOCK key twice"
	Write-Host "Note: This is not expected to work during Remote Desktop Protocol (RDP). For RDP please use the script with -k parameter instead"
}

if ($notmyfault) {
	Set-FullCrashDump
	if (!$RemoteRun) {
		[string]$notmyfault=(Read-Host "Type 'crashnow' and press ENTER to crash the machine and create a full machine dump now")
	}
	if (($notmyfault -eq "crashnow") -or ($RemoteRun)) {
		if ([Environment]::Is64BitOperatingSystem) {
			$NotMyFaultCommand = Join-Path $outputDir "NotMyFaultc64.exe"
		} else {
			$NotMyFaultCommand = Join-Path $outputDir "NotMyFaultc.exe"
		}
		& $NotMyFaultCommand /accepteula /Crash 1
	}
}

if (Test-Path -Path  $env:SystemRoot\System32\'Winevt\Logs\Operations Manager.evtx') {
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Operations Manager.evtx' -Destination $resultOutputDir\EventLogs\OperationsManager.evtx
}

if (Test-Path -Path  $env:SystemRoot\System32\'Winevt\Logs\OMS Gateway Log.evtx') {
	Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\OMS Gateway Log.evtx' -Destination $resultOutputDir\EventLogs\OMSGatewayLog.evtx
}

if (test-path -Path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-UniversalTelemetryClient%4Operational.evtx') {
	Copy-Item -path $env:SystemRoot\System32\Winevt\Logs\Microsoft-Windows-UniversalTelemetryClient%4Operational.evtx -Destination $resultOutputDir\EventLogs\utc.evtx
}

if (Test-Path -Path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-SENSE%4Operational.evtx') {
	Copy-Item -path $env:SystemRoot\System32\Winevt\Logs\Microsoft-Windows-SENSE%4Operational.evtx -Destination $resultOutputDir\EventLogs\sense.evtx
	Copy-Item -path $env:SystemRoot\System32\Winevt\Logs\Microsoft-Windows-SenseIR%4Operational.evtx -Destination $resultOutputDir\EventLogs\senseIR.evtx -ErrorAction SilentlyContinue
}

# Test for ASR rule blocking PsExec
if ((!$OSPreviousVersion) -and (!$AVPassiveMode)){
	TestASRRules    
}

# Test for DiagTrack listener on RS4 and earlier Win10 builds or SenseOms for Down-level OS, and export network proxy Registry settings
$buildNumber = ([System.Environment]::OSVersion).Version.build
Write-output "`r`n#################### Data Collection Registry setting #####################" | Out-File $connectivityCheckFile -Append
Get-Item HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection -ErrorAction SilentlyContinue| Out-File $connectivityCheckFile -Append
if ((!$OSPreviousVersion) -and ($buildNumber -le "17134")){
	Write-output "`r`n######################## DiagTrack Listener check #########################" | Out-File $connectivityCheckFile -Append
	$DiagTrackListener = &logman Diagtrack-Seville-Listener -ets
	$DiagTrackListener > "$resultOutputDir\SystemInfoLogs\DiagTrackListener.txt"
	$SevilleProv = $DiagTrackListener | Select-String "CB2FF72D-D4E4-585D-33F9-F3A395C40BE7"
	if ($SevilleProv -eq $null) {
		Write-output "DiagTrack listener missing. Please make sure *.settings-win.data.microsoft.com is not blocked in your network - contact Microsoft support if issue persists" | Out-File $connectivityCheckFile -Append
	}
	else {
		Write-output "DiagTrack listener detected" | Out-File $connectivityCheckFile -Append
	}	
} elseif ($OSPreviousVersion) {
	Write-output "`r`n######################## SenseOms Listener check #########################" | Out-File $connectivityCheckFile -Append
	$SenseOmsListener = &logman SenseOms -ets
	$SenseOmsListener > "$resultOutputDir\SystemInfoLogs\SenseOmsListener.txt"
	$OmsProv = $SenseOmsListener | Select-String "CB2FF72D-D4E4-585D-33F9-F3A395C40BE7"
	if ($OmsProv -eq $null) {
		Write-output "SenseOms listener missing. This machine is unable to upload cyber data - contact Microsoft support if issue persists" | Out-File $connectivityCheckFile -Append
	}
	else {
		Write-output "SenseOms listener detected" | Out-File $connectivityCheckFile -Append
	}	
}

# Test for existence of unsupported ProcessMitigationOptions and dump IFEO
# Reference https://docs.microsoft.com/en-us/windows/security/threat-protection/override-mitigation-options-for-app-related-security-policies
Get-childItem -Recurse "HKLM:SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" | Out-File "$resultOutputDir\SystemInfoLogs\IFEO.txt"
Get-Item "HKLM:SYSTEM\CurrentControlSet\Control\Session Manager\kernel" | Out-File "$resultOutputDir\SystemInfoLogs\SessionManager.txt"
if ((!$OSPreviousVersion) -and ($buildNumber -le "17134") -and ((Get-Service DiagTrack).Status -eq "StartPending")){
		If (Get-RegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" -Value "MitigationOptions") {
			Write-output "`r`n######################## ProcessMitigations check #########################" | Out-File $connectivityCheckFile -Append
			Write-Output "Current Process Mitigation Options in the registry are unsupported and may prevent the DiagTrack service from starting as expected." | Out-File $connectivityCheckFile -Append
			Write-output "The detected Kernel settings are : " | Out-File $connectivityCheckFile -Append
			Get-Item -path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" -ErrorAction SilentlyContinue | Out-File $connectivityCheckFile -Append
			Write-output "The detected SvcHost settings are : " | Out-File $connectivityCheckFile -Append
			Get-Item -path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\svchost.exe" -ErrorAction SilentlyContinue | Out-File $connectivityCheckFile -Append
			Write-Output "Note: Unsupported process mitigation options may also cause the DiagTrack listener to appear as missing.`r`n" | Out-File $connectivityCheckFile -Append
			Write-Warning "DiagTrack service is unable to start. This may be caused by unsupported process MitigationOptions. Please try removing the registry settings below and check if problem persists:`r`n"
			write-host "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel\MitigationOptions"
			write-host "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\svchost.exe\MitigationOptions"
		}	
}

# Test if running on unsupported Windows 10 or 2012 RTM OS
if ((($OSProductName -match 'Windows 10') -and ($OSBuild -lt "14393")) -or ($OSBuild -eq "9200")) {
	Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please note the machine OS build is not supported by MDATP and cannot be onboarded"
	Write-Host "Please refer to this article for a list of supported Windows versions: https://docs.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/minimum-requirements#hardware-and-software-requirements"
	Write-output "`r`n######################## Unsupported Win OS check #########################" | Out-File $connectivityCheckFile -Append
	Write-output "Windows machine build is unsupported:" $OSBuild | Out-File $connectivityCheckFile -Append
}

# Test for WSAEPROVIDERFAILEDINIT event related to LSP in netsh winsock catalog
if (!$OSPreviousVersion) {
	$Winsock = &netsh winsock show catalog
	$winsock | Out-File $resultOutputDir\SystemInfoLogs\winsock_catalog.txt
	if ($winsock -like "*FwcWsp64.dll*") {
		$EventError = Get-MatchingEvent Microsoft-Windows-UniversalTelemetryClient 29 "2147952506"
		if ($EventError -ne $null) {
			Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please note the machine is showing error ID WSAEPROVIDERFAILEDINIT in the UTC log. This may be caused by Forefront TMG Client Winsock LSP which is incompatible with MDATP."
			Write-Host "Please uninstall TMG firewall client from the affected machine and check if issue persists."
			Write-output "`r`n############################ Winsock error check ###############################" | Out-File $connectivityCheckFile -Append
			Write-output "Please note the machine is showing error ID WSAEPROVIDERFAILEDINIT in the UTC log. This may be caused by Forefront TMG Client Winsock LSP which is incompatible with MDATP." | Out-File $connectivityCheckFile -Append
			$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
		}
	}
}

# Dump FSUTIL USN queryjournal output to log
$DriveLetters = (Get-PSDrive -PSProvider FileSystem) | where {$_.Free -ne $null} | ForEach-Object {$_.Name}
Write-output "`r`n######################## FSUTIL USN journal query #########################" | Out-File $connectivityCheckFile -Append
foreach ($DriveLetter in $DriveLetters) {
    Write-output "USN query journal output for Drive: " $DriveLetter | Out-File $connectivityCheckFile -Append
    &fsutil usn queryjournal ("$DriveLetter" + ":") |  Out-File $connectivityCheckFile -Append
}

# Dump AddRemovePrograms to file
$uninstallKeys = Get-ChildItem HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall
Get-InstalledPrograms $uninstallKeys | Export-Csv -Path $resultOutputDir\SystemInfoLogs\AddRemovePrograms.csv -NoTypeInformation -Encoding UTF8
$uninstallKeys = Get-ChildItem HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall -ErrorAction SilentlyContinue
if ($uninstallKeys) {
	Get-InstalledPrograms $uninstallKeys | Export-Csv -Path $resultOutputDir\SystemInfoLogs\AddRemoveProgramsWOW64.csv -NoTypeInformation -Encoding UTF8
}

# Dump applied group policy if one of the below advanced scenarios was called:
if ($NetTraceI -or $AppCompatC -or $BootTraceB) {
	&gpresult /SCOPE COMPUTER /H $resultOutputDir\SystemInfoLogs\GPReport.html
}

# Check if machine was onboarded using VDI script and dump relevant information
If (Get-RegistryValue -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\DeviceTagging" -Value "VDI") {
	Write-output "`r`n######################## VDI Information #########################" | Out-File $connectivityCheckFile -Append
	Write-output "Machine was onboarded via VDI PowerShell Script. Please ensure best practices are implemented based on below articles:" | Out-File $connectivityCheckFile -Append
	Write-output "https://docs.microsoft.com/en-us/windows/security/threat-protection/microsoft-defender-atp/configure-endpoints-vdi" | Out-File $connectivityCheckFile -Append
	Write-output "https://docs.microsoft.com/en-us/windows/security/threat-protection/windows-defender-antivirus/deployment-vdi-windows-defender-antivirus" | Out-File $connectivityCheckFile -Append
	Write-output "`r`nContent of Startup folder will be logged below for reference:" | Out-File $connectivityCheckFile -Append
	$StartupFolder = (get-ChildItem -Recurse -path $env:SystemRoot\system32\GroupPolicy\Machine\Scripts\Startup) 
	Write-output $StartupFolder | Out-File $connectivityCheckFile -Append
}

# Check if automatic update of Trusted Root Certificates is blocked
$AuthRootLocal = get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\SystemCertificates\AuthRoot" -ErrorAction SilentlyContinue
$AuthRootGPO = get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\SystemCertificates\AuthRoot" -ErrorAction SilentlyContinue
if (($AuthRootLocal.DisableRootAutoUpdate -eq "1") -or ($AuthRootGPO.DisableRootAutoUpdate -eq "1")) {
	Write-output "`r`n######################## Auth Root Policies #########################" | Out-File $connectivityCheckFile -Append
    $AuthRootLocal | Out-File $connectivityCheckFile -Append
    $AuthRootGPO | Out-File $connectivityCheckFile -Append
    Write-Host "Please note that this machine is not set to automatically update Trusted Root Certificates from Windows Update"
    if ($OSPreviousVersion) {
		$EventError = Get-MatchingEvent HealthService 2132 "12175L"
	} else {
		$EventError = Get-MatchingEvent Microsoft-Windows-SENSE 5 "12175"
	}
    if ($EventError) {
		Write-Host -BackgroundColor Red -ForegroundColor Yellow "This machine has errors indicating secure connection could not be negotiated in the event logs."
		Write-Host -ForegroundColor Yellow "Please ensure the Trusted Root & Third-Party Trusted Root lists are correctly updated from WSUS or Windows Update."
        Write-Host "If you are manually updating Trusted Roots, please ensure you follow guidelines in KB2813430:`r`nhttps://support.microsoft.com/en-us/help/2813430/an-update-is-available-that-enables-administrators-to-update-trusted-a`r`n"
		write-output "Event Log error information:" | Out-File $connectivityCheckFile -Append
		$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
	} 
}

# Check for issues with certificate store
if (($OSPreviousVersion) -and (Test-Path -Path $env:SystemRoot\System32\'Winevt\Logs\Operations Manager.evtx')) {
	$EventError = Get-MatchingEvent "Service Connector" 3009 "80090016"
	if ($EventError -ne $null) {
			Write-Host -BackgroundColor Red -ForegroundColor Yellow "Please note the machine has error 'Loading the private key for the client authentication certificate' in the OpsMgr log."
			Write-Host -ForegroundColor Yellow "`r`nPlease uninstall and re-install MMA (Microsoft Monitoring Agent) on this machine and check if the issue persists."
			Write-output "`r`n###################### MMA certificate error check #########################" | Out-File $connectivityCheckFile -Append
			Write-output "Please note the machine has errors 'Loading the private key for the client authentication certificate' in the OpsMgr log." | Out-File $connectivityCheckFile -Append
			$EventError | ft -Wrap | Out-File $connectivityCheckFile -Append
	}
}

# Check for issues with Default paths or reg keys
# Taken from amcore/wcd/Source/Setup/Manifest/Windows-SenseClient-Service.man
$DefaultPaths = 
    @{
        Name = "Default MDATP Policies key"
        Path  = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection"
    },
    @{
        Name = "Default MDATP Sensor Service key"
        Path  = "HKLM:\SYSTEM\CurrentControlSet\Services\Sense"
    },
        @{
        Name = "Default MDATP directory path"
        Path  = "$env:ProgramFiles\Windows Defender Advanced Threat Protection"
    },
        @{
        Name = "Default MDATP ProgramData directory path"
        Path = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection"
    },
        @{
        Name = "Default MDATP Cache directory path"
        Path  = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection\Cache"
    },
        @{
        Name = "Default MDATP Cyber directory path"
        Path  = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection\Cyber"
    },
        @{
        Name = "Default MDATP Temp directory path"
        Path  = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection\Temp"
    },
        @{
        Name = "Defalt MDATP Trace directory path"
        Path  = "$env:ProgramData\Microsoft\Windows Defender Advanced Threat Protection\Trace"
}
if (!$OSPreviousVersion) {
	foreach ($item in $DefaultPaths) {
		if (!(Test-Path $item.Path)) {
			$MissingDefaultPath += $("`r`n" + $item.Name)
			$MissingDefaultPath += $("`r`n" + $item.Path + "`n")
		}
	}
	if ($MissingDefaultPath) {
			Write-Host -BackgroundColor Red -ForegroundColor Yellow "Default paths are missing. Please ensure the missing path(s) exist and have not been renamed:"
			Write-Host $MissingDefaultPath
			Write-output "`r`n###################### Missing default path check #########################" | Out-File $connectivityCheckFile -Append
			Write-output "Default paths are missing. Please ensure the missing path(s) exist and have not been renamed:" | Out-File $connectivityCheckFile -Append
			$MissingDefaultPath | ft -Wrap | Out-File $connectivityCheckFile -Append
	}
}

Write-output "`r`n###################### MDATP CommandLine usage information #########################"  | Out-File $connectivityCheckFile -Append 
[environment]::GetCommandLineArgs() | Out-File $connectivityCheckFile -Append

[version]$PSMinVer = '2.0.1.1'
if ( $PSVersionTable.PSVersion -gt $PSMinVer) {
    Add-Type -Assembly "System.IO.Compression.FileSystem";
    [System.IO.Compression.ZipFile]::CreateFromDirectory($resultOutputDir, $outputZipFile)
    Write-Host "Result is available at: " $outputZipFile
} else {
     Write-Host "Result is available at: " $resultOutputDir
}
# SIG # Begin signature block
# MIIjhgYJKoZIhvcNAQcCoIIjdzCCI3MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAgTio068kFMxxy
# 5tnEdctsAqZa8M/Fqvkks9Fmbk5A86CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVWzCCFVcCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgSN9X2YzD
# 1CDJ9yETZzxe3b2t9O0dS6qvV9V1TqLBtvgwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQAk57RKZe8IlnPJUOuu+bM1rKV7UPkef6LadAAyJtsG
# 8csxQXcnpq7uhtiAPpAZT7zqJBRRqePiIq+chXURVaNqFoQ471myYhsu51oT+H0b
# PPz3T7Henfs56gFXkgdZloUMYbil4ApQagT2DzMybH3ZJD1mXoEu02ZhMuicgObu
# SVkFZZglnvVuY5KK21rOC2WcFP+gMk1fJdoLX7xARuBksXAipbMp0CerlsDxu+Fr
# 0iqLbx5fGFCFRZetVRC8LhBBO4R1LmhlCu/8BkjlNd0GM0Pht2v/JcmZsOBlejM3
# gj4geImgE0FSDpWbQRsA9t//sVLRFCyQEVczMzLmewWboYIS5TCCEuEGCisGAQQB
# gjcDAwExghLRMIISzQYJKoZIhvcNAQcCoIISvjCCEroCAQMxDzANBglghkgBZQME
# AgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIIQiMU9YyrH8vf+Ra6VclrGr12OlpBmrge6w+4jx
# wlA5AgZeSsKJSYcYEzIwMjAwMzA5MTM1NjI4LjMwNVowBIACAfSggdCkgc0wgcox
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1p
# Y3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOkQyQ0QtRTMxMC00QUYxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloIIOPDCCBPEwggPZoAMCAQICEzMAAAEiG48AJiXMsecAAAAAASIw
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MTkxMTEzMjE0MDQzWhcNMjEwMjExMjE0MDQzWjCByjELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2Eg
# T3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RDJDRC1FMzEwLTRB
# RjExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDfFQNIYkE+wXLcD2Ufk2s4kUKUhTQ9
# 5+R/Q6DUhduOGdLJsSKhocU1Kl8L1zEqk/k1k+5oVCiBp5L9FO7ycSh779B+Q8Te
# iERLM+nbMdsAxUCbPjR0sQ63kJTFpDgB/4HOpeLULMPQ6iEl0jfEs2uqdt/gWIq4
# KyK0ZXoP/Oo6S7zhWz4Cjczk7gS0ilAfSt7xB5lEhQhLCtkp9rzO6CKqMLW5ujYV
# yhmFcfrdx74/Y6E2Gs9u1YOk8Ktn4Y4cW/2E2e+4BeMs9AS+0XWbk/NYY2xiPHjZ
# qlzoVZEKGldOJ09P+kIh/jntp3Tpqr2NTeDt9OjT1qUY1yzJddR0pcLJAgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQUjjY9VWprwC9x2Djj4TS9nRczt8gwHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEAi6RHbsMi/wa2g3J+VTuchJyiNZ0fZlqWuihOJOux
# N59QvCd66Hp2pBaRCF4jfx+wbrGEeOdJ5luTZIUD88hJof4Q7Q37ZX78snbMd/gh
# r177Z1bf7t3yRM2cQ3vH6j20jWtlacoWeG/CRsCX0VHy/5o+qJxb/SfVC5WB+aZB
# cF/j7cdzHls7CMcTpzDaon2+q5J0mB+bV/I7kGyLx4kIQOgvox1xeXywxtFOgVef
# BCKYHL59hLoQZsOUwr8k8kd/P8wWckaDTuWt/uRq41wzYw/nd3ACzfTHVF6DY9qQ
# FQVEGJ0RA4cEs6EIX94sN/zpVTnUG+0PPdXBcgBKUkjK2zCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCAs4wggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBP
# cGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpEMkNELUUzMTAtNEFG
# MTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUAUOwD/JcbpKVMXpF2Vh77MyVNm9mggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOIQR2cwIhgPMjAy
# MDAzMDkxMjQxMTFaGA8yMDIwMDMxMDEyNDExMVowdzA9BgorBgEEAYRZCgQBMS8w
# LTAKAgUA4hBHZwIBADAKAgEAAgISXgIB/zAHAgEAAgIRoTAKAgUA4hGY5wIBADA2
# BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIB
# AAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAHaE6TKUvlYG8lN+NZ5nP9Ujt9w2MlIw
# M4QKV41TObWBnvcBXFEEd/Ln4e48SssSTZir5FscImNjK4qTBzNhH9VWcjIt7F05
# 9wbmPxEZ3/4unonJIvgKfzL7F/eKpdtc1CJ8cEYMxUyfcguUqDweueq4up3BbynW
# N4xko5HaZ4kiMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAEiG48AJiXMsecAAAAAASIwDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgK7hz+tdv
# SlyU+97o6tVnw4TeYrscLvhCQVMyC1TIODwwgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCC78GCJXmIyzmqyWSlw5bflow9yQ3g4vvs34oNSwngxCTCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABIhuPACYlzLHnAAAA
# AAEiMCIEIEHyDUPLYyabzX0FOUDLa8/jrF9hUYzDHwMXH2cf9E4GMA0GCSqGSIb3
# DQEBCwUABIIBABUMo8UVsfAmGw+HYe725NJb6NJ2ZCJTExLxK9ARiTtBhRxOGMOz
# kE9D8qg9KPc6gMts8dnKbE6MI82NzFjjnsbeXmnwQeEYN9WdKKXXGinKO8Jhe2cK
# 2fr3cYCLxXnJ+JyG+Rro2nEcdmnhrSudHLbG1DM8gk86VSNXBW5c3ggnBkgnU/OU
# ppvX+6+33Za0/am6v9+ZB1lIMxJBbj5zw+G3kiY/Si4I4SGdZOecqRftW19tJDzj
# SHA6iGInY+zaiG02O+HEDQGfmxqhAM4IVwVMDubm90945TusVsNIzq+hV+7lV6qW
# IH74/dgi33Fz0KlVdHqfLFXgbU2dcwFNtDo=
# SIG # End signature block
